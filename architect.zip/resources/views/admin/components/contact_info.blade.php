            <!---Admin sections--->
            <section class="admin__panel__content-section">
                <div class="section__name__elements">
                    <div class="section__name__name">
                        Əlaqə məlumatları
                    </div>
                    <div class="section__element__search_add">

                    </div>
                </div>

                <div class="section__content__wrapper">

                </div>

            </section>
